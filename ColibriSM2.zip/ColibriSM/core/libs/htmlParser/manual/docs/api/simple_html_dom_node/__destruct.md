# __destruct

```php
__destruct ( )
```

Destructs the current object and frees memory.